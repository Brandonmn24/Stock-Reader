﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static Project_1.Recognizers;

namespace Project_1
{
    public partial class Form_Display : Form
    {
        //  Fields 
        public List<aCandlestick> listOfCandlesticks;          // all candles from file
        public List<aCandlestick> filteredCandlesticks;        // candles in selected date range
        public List<aCandlestick> simulatedCandlesticks =
            new List<aCandlestick>();                          // used for ticker simulation

        // Smart candlesticks (built from filteredCandlesticks, used by Recognizers)
        private List<aSmartCandlestick> listOfSmartCandles =
            new List<aSmartCandlestick>();

        string ticker;
        int simulationIndex = 0;

        // List of Recognizers (LOR on the board)
        List<Recognizer> LOR = new List<Recognizer>();

        /// <summary>
        /// constructors
        /// </summary>
        public Form_Display()
        {
            InitializeComponent();
            InitializeRecognizers();
            comboBox_Candlesticks.SelectedIndexChanged += comboBox_Candlesticks_SelectedIndexChanged;
        }

        // Used by Form_Home to pass file + dates
        /// <summary>
        /// loads the specified file and displays candlesticks in the given date range
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        public Form_Display(string fileName, DateTime startDate, DateTime endDate)
        {
            InitializeComponent(); // 1st line in ctor
            InitializeRecognizers(); // set up recognizers + combobox
            comboBox_Candlesticks.SelectedIndexChanged += comboBox_Candlesticks_SelectedIndexChanged; // subscribe to event

            dateTimePicker_startDate.Value = startDate; // set date pickers
            dateTimePicker_endDate.Value = endDate; // set date pickers
            ticker = Path.GetFileNameWithoutExtension(fileName); // extract ticker from filename

            openFileDialog_fileSelector.FileName = fileName; // set open file dialog filename

            listOfCandlesticks = ReadCandleStickFile(fileName); // read file
            filteredCandlesticks = filterCandlesticks(
                listOfCandlesticks,
                dateTimePicker_startDate.Value,
                dateTimePicker_endDate.Value); // filter by dates

            // Build smart candles for pattern recognition
            listOfSmartCandles = BuildSmartCandles(filteredCandlesticks); // build smart candles

            update(listOfCandlesticks); // update display
        }

        //Recognizers / ComboBox
        /// <summary>
        /// initializes the list of recognizers and fills the combobox with their names
        /// </summary>
        void InitializeRecognizers()
        {
            LOR = new List<Recognizer>();

            LOR.Add(new Recognizer_Doji());
            LOR.Add(new Recognizer_BullishDoji());
            LOR.Add(new Recognizer_BearishDoji());
            LOR.Add(new Recognizer_DragonflyDoji());
            LOR.Add(new Recognizer_GravestoneDoji());


            LOR.Add(new Recognizer_Hammer());
            LOR.Add(new Recognizer_BullishHammer());
            LOR.Add(new Recognizer_BearishHammer());

            LOR.Add(new Recognizer_InvertedHammer());
            LOR.Add(new Recognizer_BullishInvertedHammer());
            LOR.Add(new Recognizer_BearishInvertedHammer());

            LOR.Add(new Recognizer_Marubozu());
            LOR.Add(new Recognizer_BullishMarubozu());
            LOR.Add(new Recognizer_BearishMarubozu());

            LOR.Add(new Recognizer_Engulfing());
            LOR.Add(new Recognizer_BullishEngulfing());
            LOR.Add(new Recognizer_BearishEngulfing());

            LOR.Add(new Recognizer_Harami());
            LOR.Add(new Recognizer_BullishHarami());
            LOR.Add(new Recognizer_BearishHarami());

            comboBox_Candlesticks.Items.Clear();
            foreach (var r in LOR)
                comboBox_Candlesticks.Items.Add(r.PatternName);
        }

        /// <summary>
        ///  Build smart candlesticks from a base list
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        private List<aSmartCandlestick> BuildSmartCandles(IEnumerable<aCandlestick> src)
        {
            var smart = new List<aSmartCandlestick>();
            if (src == null) return smart;

            foreach (var c in src)
                smart.Add(new aSmartCandlestick(c));

            return smart;
        }

        /// <summary>
        /// File & filtering
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_fireOpenFileDialog_Click(object sender, EventArgs e)
        {
            DialogResult dr = openFileDialog_fileSelector.ShowDialog();
            if (dr == DialogResult.OK)
            {
                button_refresh.Enabled = true;
            }
        }
        /// <summary>
        /// select file dialog OK event handler and created filtered list and smart candles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileDialog_fileSelector_FileOk(object sender, CancelEventArgs e)
        {
            string fileName = openFileDialog_fileSelector.FileName;
            ticker = Path.GetFileNameWithoutExtension(fileName);

            listOfCandlesticks = ReadCandleStickFile(fileName);
            filteredCandlesticks = filterCandlesticks(
                listOfCandlesticks,
                dateTimePicker_startDate.Value,
                dateTimePicker_endDate.Value);

            listOfSmartCandles = BuildSmartCandles(filteredCandlesticks);

            update(listOfCandlesticks);
        }
        /// <summary>
        /// read candlestick data from file
        /// </summary>
        /// <param name="tickerFile"></param>
        /// <returns></returns>
        public List<aCandlestick> ReadCandleStickFile(string tickerFile)
        {
            List<aCandlestick> candlesticks = new List<aCandlestick>(); // list to hold candlesticks

            try
            {
                string text;
                using (StreamReader reader = new StreamReader(tickerFile)) // read file
                {
                    text = reader.ReadToEnd(); // read entire file content
                }

                char[] lineDelimiter = new char[] { '\n' }; // define line delimiter
                string[] lines = text.Split(lineDelimiter, StringSplitOptions.RemoveEmptyEntries); // split into lines

                // start at 1 to skip header
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    aCandlestick c = new aCandlestick(line); // create candlestick from line
                    candlesticks.Add(c);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(ex.Message);
            }

            return candlesticks;
        }
        /// <summary>
        /// gets filtered list of candlesticks in the given date range
        /// </summary>
        /// <param name="orginalList"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public List<aCandlestick> filterCandlesticks(
            List<aCandlestick> orginalList,
            DateTime startDate,
            DateTime endDate)
        {
            var filteredList = new List<aCandlestick>();

            foreach (var candlestick in orginalList.OrderBy(c => c.date))
            {
                if (candlestick.date < startDate) continue;
                if (candlestick.date > endDate) break;
                filteredList.Add(candlestick);
            }

            return filteredList;
        }

        /// <summary>
        /// normalizes the chart Y-axis based on min/max of given candlestick list
        /// </summary>
        /// <param name="listOfCandlesticks"></param>
        public void normalizeChart(List<aCandlestick> listOfCandlesticks)
        {
            if (listOfCandlesticks == null || listOfCandlesticks.Count == 0)
                return;

            decimal minimumVal = listOfCandlesticks.Min(c => c.low); // find minimum low value
            decimal maximumVal = listOfCandlesticks.Max(c => c.high); // find maximum high value

            decimal padding = (maximumVal - minimumVal) * 0.02m;
            decimal minY = minimumVal - padding;
            decimal maxY = maximumVal + padding;

            chart_OHLCV.ChartAreas["ChartArea_stock"].AxisY.Minimum = Math.Floor((double)minY); // set Y-axis minimum
            chart_OHLCV.ChartAreas["ChartArea_stock"].AxisY.Maximum = Math.Ceiling((double)maxY); // set Y-axis maximum
        }
        /// <summary>
        /// displays the chart for the given list of candlesticks and rebinds the data
        /// </summary>
        /// <param name="listOfCandlesticks"></param>
        public void displayChart(List<aCandlestick> listOfCandlesticks)
        {
            aCandlestickBindingSource.DataSource = listOfCandlesticks;
            normalizeChart(listOfCandlesticks);

            chart_OHLCV.DataSource = listOfCandlesticks;
            chart_OHLCV.DataBind();

            chart_OHLCV.Titles.Clear();
            chart_OHLCV.Titles.Add(ticker);
            chart_OHLCV.Titles.Add(
                $"{dateTimePicker_startDate.Value:d} -- {dateTimePicker_endDate.Value:d}");

            Show();
        }
        /// <summary>
        /// updates the display with the given source list (applies filtering, rebuilds smart candles, updates chart)
        /// </summary>
        /// <param name="sourceList"></param>
        public void update(List<aCandlestick> sourceList)
        {
            if (sourceList == null) return;

            var filtered = filterCandlesticks(
                sourceList,
                dateTimePicker_startDate.Value,
                dateTimePicker_endDate.Value); // apply date filtering
             
            filteredCandlesticks = filtered; // update field
            listOfSmartCandles = BuildSmartCandles(filtered); // rebuild smart candles

            aCandlestickBindingSource.DataSource = filtered; // update binding source
            displayChart(filtered); // update chart display
        }
        /// <summary>
        /// add annotations to every 3rd candlestick in the simulated list
        /// </summary>
        private void addAnnotations()
        {
            chart_OHLCV.Annotations.Clear(); // clear existing annotations
            for (int n = 0; n < simulatedCandlesticks.Count; n++)
            {
                DataPoint dp = chart_OHLCV.Series["Series_OHLC"].Points[n];
                if (n % 3 == 0) // every 3rd candlestick
                {
                    TextAnnotation annotation = new TextAnnotation { Text = "Candle " + n.ToString(), AnchorDataPoint = dp, Alignment = ContentAlignment.TopCenter, }; // create annotation
                    chart_OHLCV.Annotations.Add(annotation);
                }
            }
        }
        /// <summary>
        /// updates on button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_refresh_Click(object sender, EventArgs e)
        {
            if (listOfCandlesticks != null)
                update(listOfCandlesticks);
        }

        /// <summary>
        /// simulates ticker by displaying one candlestick at a time
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_Simulate_Click(object sender, EventArgs e)
        {
            if (filteredCandlesticks == null || filteredCandlesticks.Count == 0)
                return;

            simulatedCandlesticks.Clear(); // clear simulated list
            chart_OHLCV.Annotations.Clear(); // clear annotations
            simulationIndex = 0; // reset simulation index

            chart_OHLCV.DataSource = simulatedCandlesticks; // bind to simulated list
            chart_OHLCV.DataBind(); // initial bind

            timer_simulate.Start(); // start timer

        }
        /// <summary>
        /// timer tick event handler for simulation and add annotations
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_simulate_Tick(object sender, EventArgs e)
        {
            timer_simulate.Stop(); //stop any timers running
            displayNextCandlestick(); //display next candlestick in simulation
            if (simulatedCandlesticks.Count < filteredCandlesticks.Count)
            {
                
                timer_simulate.Start(); //if there are more candlesticks start
            }
            else { 
                addAnnotations(); // add annos at the end
            }
            
        }
        /// <summary>
        /// displays the next candlestick in the simulation
        /// </summary>
        private void displayNextCandlestick()
        {
            if (filteredCandlesticks == null || filteredCandlesticks.Count == 0)
                return;

            if (simulatedCandlesticks.Count >= filteredCandlesticks.Count)
                return;

            // just reuse the object – no need for a copy ctor
            aCandlestick nextCandlestick = filteredCandlesticks[simulatedCandlesticks.Count]; // get next candlestick
            simulatedCandlesticks.Add(nextCandlestick); // add to simulated list

            normalizeChart(simulatedCandlesticks); // normalize chart for each update
            chart_OHLCV.DataBind(); // rebind data
        }
        /// <summary>
        /// increases/decreases timer interval based on scrollbar value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void hScrollBar_Simulate_Scroll(object sender, ScrollEventArgs e)
        {
         
            timer_simulate.Interval = hScrollBar_Simulate.Value;
            textBox_number.Text = hScrollBar_Simulate.Value.ToString();
        }

        /// <summary>
        /// Pattern recognition via ComboBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_Candlesticks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_Candlesticks.SelectedIndex < 0)
                return;
            if (filteredCandlesticks == null || filteredCandlesticks.Count == 0)
                return;

            //Make sure the chart is showing ALL filtered candles
            chart_OHLCV.DataSource = filteredCandlesticks;
            chart_OHLCV.DataBind();
            normalizeChart(filteredCandlesticks);

            // Rebuild smart candles from the filtered list 
            listOfSmartCandles = BuildSmartCandles(filteredCandlesticks);

            //selected recognizer
            Recognizer r = LOR[comboBox_Candlesticks.SelectedIndex];
            r.Scan(listOfSmartCandles);   // fills r.PatternIndices

           

            //Clear old annotations
            chart_OHLCV.Annotations.Clear();

            // Add new annotations at pattern indices
            Series series = chart_OHLCV.Series["Series_OHLC"];

            foreach (int index in r.PatternIndices) // for each detected pattern index
            {
                if (index < 0 || index >= series.Points.Count)
                    continue;

                DataPoint dp = series.Points[index]; // get corresponding DataPoint

                var ann = new RectangleAnnotation
                {
                    AnchorDataPoint = dp,
                    Text = r.PatternName,
                    Alignment = ContentAlignment.TopCenter,

                }; // create annotation

                chart_OHLCV.Annotations.Add(ann);
            }
        }

        
    }
}
