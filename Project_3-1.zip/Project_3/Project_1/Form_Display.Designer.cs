﻿namespace Project_1
{
    partial class Form_Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.button_fireOpenFileDialog = new System.Windows.Forms.Button();
            this.button_refresh = new System.Windows.Forms.Button();
            this.openFileDialog_fileSelector = new System.Windows.Forms.OpenFileDialog();
            this.chart_OHLCV = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dateTimePicker_startDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_endDate = new System.Windows.Forms.DateTimePicker();
            this.label_startDate = new System.Windows.Forms.Label();
            this.label_endDate = new System.Windows.Forms.Label();
            this.button_Simulate = new System.Windows.Forms.Button();
            this.aCandlestickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timer_simulate = new System.Windows.Forms.Timer(this.components);
            this.comboBox_Candlesticks = new System.Windows.Forms.ComboBox();
            this.textBox_number = new System.Windows.Forms.TextBox();
            this.hScrollBar_Simulate = new System.Windows.Forms.HScrollBar();
            ((System.ComponentModel.ISupportInitialize)(this.chart_OHLCV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCandlestickBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button_fireOpenFileDialog
            // 
            this.button_fireOpenFileDialog.Location = new System.Drawing.Point(305, 388);
            this.button_fireOpenFileDialog.Name = "button_fireOpenFileDialog";
            this.button_fireOpenFileDialog.Size = new System.Drawing.Size(93, 23);
            this.button_fireOpenFileDialog.TabIndex = 0;
            this.button_fireOpenFileDialog.Text = "Select Stock";
            this.button_fireOpenFileDialog.UseVisualStyleBackColor = true;
            this.button_fireOpenFileDialog.Click += new System.EventHandler(this.button_fireOpenFileDialog_Click);
            // 
            // button_refresh
            // 
            this.button_refresh.Location = new System.Drawing.Point(700, 389);
            this.button_refresh.Name = "button_refresh";
            this.button_refresh.Size = new System.Drawing.Size(75, 23);
            this.button_refresh.TabIndex = 1;
            this.button_refresh.Text = "Refresh";
            this.button_refresh.UseVisualStyleBackColor = true;
            this.button_refresh.Click += new System.EventHandler(this.button_refresh_Click);
            // 
            // openFileDialog_fileSelector
            // 
            this.openFileDialog_fileSelector.DefaultExt = "csv";
            this.openFileDialog_fileSelector.FileName = "ABBV-Day";
            this.openFileDialog_fileSelector.Filter = "All Files|*.csv|Monthly Files|*-Month.csv|Weekly Files|*-Week.csv|Daily Files|*-d" +
    "ay.csv";
            this.openFileDialog_fileSelector.InitialDirectory = "C:\\Users\\nbran\\OneDrive\\Desktop\\Stock Data";
            this.openFileDialog_fileSelector.Multiselect = true;
            this.openFileDialog_fileSelector.Title = "Please select one and only one stock to read";
            this.openFileDialog_fileSelector.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_fileSelector_FileOk);
            // 
            // chart_OHLCV
            // 
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.Name = "ChartArea_stock";
            chartArea2.AlignWithChartArea = "ChartArea_stock";
            chartArea2.Name = "ChartArea_volume";
            this.chart_OHLCV.ChartAreas.Add(chartArea1);
            this.chart_OHLCV.ChartAreas.Add(chartArea2);
            this.chart_OHLCV.Dock = System.Windows.Forms.DockStyle.Top;
            this.chart_OHLCV.Location = new System.Drawing.Point(0, 0);
            this.chart_OHLCV.Name = "chart_OHLCV";
            series1.ChartArea = "ChartArea_stock";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series1.CustomProperties = "PriceDownColor=Red, PriceUpColor=Lime";
            series1.IsXValueIndexed = true;
            series1.Name = "Series_OHLC";
            series1.XValueMember = "date";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series1.YValueMembers = "high, low, open, close";
            series1.YValuesPerPoint = 4;
            series2.ChartArea = "ChartArea_volume";
            series2.IsXValueIndexed = true;
            series2.Name = "Series_volume";
            series2.XValueMember = "date";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series2.YValueMembers = "volume";
            series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt64;
            this.chart_OHLCV.Series.Add(series1);
            this.chart_OHLCV.Series.Add(series2);
            this.chart_OHLCV.Size = new System.Drawing.Size(891, 386);
            this.chart_OHLCV.TabIndex = 2;
            this.chart_OHLCV.Text = "chart1";
            // 
            // dateTimePicker_startDate
            // 
            this.dateTimePicker_startDate.Location = new System.Drawing.Point(75, 392);
            this.dateTimePicker_startDate.Name = "dateTimePicker_startDate";
            this.dateTimePicker_startDate.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_startDate.TabIndex = 3;
            this.dateTimePicker_startDate.Value = new System.DateTime(2023, 3, 24, 0, 0, 0, 0);
            // 
            // dateTimePicker_endDate
            // 
            this.dateTimePicker_endDate.Location = new System.Drawing.Point(478, 392);
            this.dateTimePicker_endDate.Name = "dateTimePicker_endDate";
            this.dateTimePicker_endDate.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_endDate.TabIndex = 4;
            this.dateTimePicker_endDate.Value = new System.DateTime(2023, 4, 24, 0, 0, 0, 0);
            // 
            // label_startDate
            // 
            this.label_startDate.AutoSize = true;
            this.label_startDate.Location = new System.Drawing.Point(11, 398);
            this.label_startDate.Name = "label_startDate";
            this.label_startDate.Size = new System.Drawing.Size(58, 13);
            this.label_startDate.TabIndex = 6;
            this.label_startDate.Text = "Start Date:";
            // 
            // label_endDate
            // 
            this.label_endDate.AutoSize = true;
            this.label_endDate.Location = new System.Drawing.Point(417, 398);
            this.label_endDate.Name = "label_endDate";
            this.label_endDate.Size = new System.Drawing.Size(55, 13);
            this.label_endDate.TabIndex = 7;
            this.label_endDate.Text = "End Date:";
            // 
            // button_Simulate
            // 
            this.button_Simulate.Location = new System.Drawing.Point(790, 389);
            this.button_Simulate.Name = "button_Simulate";
            this.button_Simulate.Size = new System.Drawing.Size(75, 23);
            this.button_Simulate.TabIndex = 8;
            this.button_Simulate.Text = "Simulate";
            this.button_Simulate.UseVisualStyleBackColor = true;
            this.button_Simulate.Click += new System.EventHandler(this.button_Simulate_Click);
            // 
            // timer_simulate
            // 
            this.timer_simulate.Tick += new System.EventHandler(this.timer_simulate_Tick);
            // 
            // comboBox_Candlesticks
            // 
            this.comboBox_Candlesticks.FormattingEnabled = true;
            this.comboBox_Candlesticks.Location = new System.Drawing.Point(722, 418);
            this.comboBox_Candlesticks.Name = "comboBox_Candlesticks";
            this.comboBox_Candlesticks.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Candlesticks.TabIndex = 9;
            this.comboBox_Candlesticks.SelectedIndexChanged += new System.EventHandler(this.comboBox_Candlesticks_SelectedIndexChanged);
            // 
            // textBox_number
            // 
            this.textBox_number.Location = new System.Drawing.Point(161, 421);
            this.textBox_number.Name = "textBox_number";
            this.textBox_number.Size = new System.Drawing.Size(100, 20);
            this.textBox_number.TabIndex = 11;

            // 
            // hScrollBar_Simulate
            // 
            this.hScrollBar_Simulate.Location = new System.Drawing.Point(29, 424);
            this.hScrollBar_Simulate.Maximum = 2000;
            this.hScrollBar_Simulate.Minimum = 100;
            this.hScrollBar_Simulate.Name = "hScrollBar_Simulate";
            this.hScrollBar_Simulate.Size = new System.Drawing.Size(129, 17);
            this.hScrollBar_Simulate.TabIndex = 12;
            this.hScrollBar_Simulate.Value = 100;
            this.hScrollBar_Simulate.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_Simulate_Scroll);
            // 
            // Form_Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 450);
            this.Controls.Add(this.hScrollBar_Simulate);
            this.Controls.Add(this.textBox_number);
            this.Controls.Add(this.comboBox_Candlesticks);
            this.Controls.Add(this.button_Simulate);
            this.Controls.Add(this.label_endDate);
            this.Controls.Add(this.label_startDate);
            this.Controls.Add(this.dateTimePicker_endDate);
            this.Controls.Add(this.dateTimePicker_startDate);
            this.Controls.Add(this.chart_OHLCV);
            this.Controls.Add(this.button_refresh);
            this.Controls.Add(this.button_fireOpenFileDialog);
            this.Name = "Form_Display";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chart_OHLCV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCandlestickBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_fireOpenFileDialog;
        private System.Windows.Forms.Button button_refresh;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_OHLCV;
        private System.Windows.Forms.DateTimePicker dateTimePicker_startDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_endDate;
        private System.Windows.Forms.OpenFileDialog openFileDialog_fileSelector;
        private System.Windows.Forms.BindingSource aCandlestickBindingSource;
        private System.Windows.Forms.Label label_startDate;
        private System.Windows.Forms.Label label_endDate;
        private System.Windows.Forms.Button button_Simulate;
        private System.Windows.Forms.ComboBox comboBox_Candlesticks;
        private System.Windows.Forms.TextBox textBox_number;
        private System.Windows.Forms.HScrollBar hScrollBar_Simulate;
        public System.Windows.Forms.Timer timer_simulate;
    }
}

