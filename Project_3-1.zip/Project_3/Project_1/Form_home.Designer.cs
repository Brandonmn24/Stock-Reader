﻿namespace Project_1
{
    partial class Form_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog_fileSelector = new System.Windows.Forms.OpenFileDialog();
            this.button_loadTicker = new System.Windows.Forms.Button();
            this.dateTimePicker_startDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_endDate = new System.Windows.Forms.DateTimePicker();
            this.label_endDate = new System.Windows.Forms.Label();
            this.label_startDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // openFileDialog_fileSelector
            // 
            this.openFileDialog_fileSelector.DefaultExt = "csv";
            this.openFileDialog_fileSelector.FileName = "ABBV-Day";
            this.openFileDialog_fileSelector.Filter = "All Files|*.csv|Monthly Files|*-Month.csv|Weekly Files|*-Week.csv|Daily Files|*-d" +
    "ay.csv";
            this.openFileDialog_fileSelector.InitialDirectory = "C:\\Users\\nbran\\OneDrive\\Desktop\\Stock Data";
            this.openFileDialog_fileSelector.Multiselect = true;
            this.openFileDialog_fileSelector.Title = "Please select one and only one stock to read";
            this.openFileDialog_fileSelector.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_fileSelector_FileOk);
            // 
            // button_loadTicker
            // 
            this.button_loadTicker.Location = new System.Drawing.Point(347, 11);
            this.button_loadTicker.Name = "button_loadTicker";
            this.button_loadTicker.Size = new System.Drawing.Size(75, 23);
            this.button_loadTicker.TabIndex = 0;
            this.button_loadTicker.Text = "Load Ticker";
            this.button_loadTicker.UseVisualStyleBackColor = true;
            this.button_loadTicker.Click += new System.EventHandler(this.button_loadTicker_Click);
            // 
            // dateTimePicker_startDate
            // 
            this.dateTimePicker_startDate.Location = new System.Drawing.Point(92, 12);
            this.dateTimePicker_startDate.Name = "dateTimePicker_startDate";
            this.dateTimePicker_startDate.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_startDate.TabIndex = 1;
            this.dateTimePicker_startDate.Value = new System.DateTime(2023, 3, 1, 13, 4, 0, 0);
            // 
            // dateTimePicker_endDate
            // 
            this.dateTimePicker_endDate.Location = new System.Drawing.Point(527, 11);
            this.dateTimePicker_endDate.Name = "dateTimePicker_endDate";
            this.dateTimePicker_endDate.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_endDate.TabIndex = 2;
            this.dateTimePicker_endDate.Value = new System.DateTime(2023, 4, 1, 13, 4, 0, 0);
            // 
            // label_endDate
            // 
            this.label_endDate.AutoSize = true;
            this.label_endDate.Location = new System.Drawing.Point(466, 16);
            this.label_endDate.Name = "label_endDate";
            this.label_endDate.Size = new System.Drawing.Size(55, 13);
            this.label_endDate.TabIndex = 3;
            this.label_endDate.Text = "End Date:";
            // 
            // label_startDate
            // 
            this.label_startDate.AutoSize = true;
            this.label_startDate.Location = new System.Drawing.Point(12, 16);
            this.label_startDate.Name = "label_startDate";
            this.label_startDate.Size = new System.Drawing.Size(58, 13);
            this.label_startDate.TabIndex = 4;
            this.label_startDate.Text = "Start Date:";
            // 
            // Form_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 38);
            this.Controls.Add(this.label_startDate);
            this.Controls.Add(this.label_endDate);
            this.Controls.Add(this.dateTimePicker_endDate);
            this.Controls.Add(this.dateTimePicker_startDate);
            this.Controls.Add(this.button_loadTicker);
            this.Name = "Form_home";
            this.Text = "Form_home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog_fileSelector;
        private System.Windows.Forms.Button button_loadTicker;
        private System.Windows.Forms.DateTimePicker dateTimePicker_startDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_endDate;
        private System.Windows.Forms.Label label_endDate;
        private System.Windows.Forms.Label label_startDate;
    }
}