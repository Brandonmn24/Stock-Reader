﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{   
    public class aCandlestick
    {
        //public string ticker { get; set; }
        //public string period { get; set; }
        //sets and gets the data for needed data to display
        public DateTime date { get; set; }
        public decimal open { get; set; }
        public decimal high { get; set; }
        public decimal low { get; set; }
        public decimal close { get; set; }
        public ulong volume { get; set; }

        private static char[] delimiters = { '"', ',', ';' }; //set of delimiters that are in the string line

        /// <summary>
        /// this is a default constructor
        /// </summary>
        public aCandlestick() { }

        
        public aCandlestick(aCandlestick otherCandleStick)
        {
            //ticker = otherCandleStick.ticker;
            //period = otherCandleStick.period;
            date = otherCandleStick.date;
            open = otherCandleStick.open;
            high = otherCandleStick.high;
            low = otherCandleStick.low;
            close = otherCandleStick.close;
            volume = otherCandleStick.volume;
        }

        /// <summary>
        /// add ticker and add stock type daily/weekly/monthly
        /// </summary>
        /// <param name="line"></param>
        public aCandlestick(string line)
        {
            CultureInfo provider = CultureInfo.InvariantCulture;
            string[] strings = line.Split(delimiters, StringSplitOptions.RemoveEmptyEntries); //split the line by delimiters

            //ticker = strings[0];
            //period = strings[1];
            string dateString = strings[2]; //at second index since ticker and period are in 0 and 1 respectively

            date = DateTime.Parse(dateString, provider); //store date as a string
            open = Math.Round(Convert.ToDecimal(strings[3]), 2); //converts string to decimal and then round to 2 decimal places
            high = Math.Round(Convert.ToDecimal(strings[4]), 2);//converts string to decimal and then round to 2 decimal places
            low = Math.Round(Convert.ToDecimal(strings[5]), 2);//converts string to decimal and then round to 2 decimal places
            close = Math.Round(Convert.ToDecimal(strings[6]), 2); //converts string to decimal and then round to 2 decimal places
            volume = Convert.ToUInt64(strings[7]); //stores volume
        }

        /// <summary>
        /// Constructor with all candlestick fields.
        /// </summary>
        public aCandlestick(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
        {
            this.date = date;
            this.open = open;
            this.high = high;
            this.low = low;
            this.close = close;
            this.volume = volume;
        }
    }
    public class aSmartCandlestick : aCandlestick
    {
        

        // For Doji
        private const decimal DOJI_BODY_MAX_PCT_OF_RANGE = 0.10m;   // 10%
        private const decimal LAX = 0.05m; //5% leniency for candlestick patterns
        // For Dragonfly / Gravestone specialization of Doji
        private const decimal LONG_TAIL_MIN_PCT_OF_RANGE = 0.60m;   // >=55% of range
        private const decimal SHORT_TAIL_MAX_PCT_OF_RANGE = 0.10m;  // <=15% of range

        // For Marubozu
        private const decimal MARUBOZU_BODY_MIN_PCT_OF_RANGE = 0.90m;   // >=90% body
        private const decimal MARUBOZU_TAIL_MAX_PCT_OF_RANGE = 0.05m;   // <=5% tail each

        // For Hammer / Inverted Hammer
        private const decimal HAMMER_BODY_MAX_PCT_OF_RANGE = 0.30m;     // body relatively small
        private const decimal HAMMER_LONG_TAIL_MIN_PCT_OF_RANGE = 0.60m; // long tail side
        private const decimal HAMMER_SHORT_TAIL_MAX_PCT_OF_RANGE = 0.10m; // short tail side

        // Small epsilon to avoid division-by-zero / tiny-range issues
        private const decimal MIN_VALID_RANGE = 0.0000001m;

        public aSmartCandlestick() : base() { } //default constructor

        /// <summary>
        /// Initializes a new instance of the aSmartCandlestick class using the specified candlestick
        /// data
        /// </summary>
 
        public aSmartCandlestick(aCandlestick c) :
            base(c.date, c.open, c.high, c.low, c.close, c.volume)
        { }

        // Anatomy properties 

        // Total high–low range
        public decimal range
        {
            get { return high - low; }
        }

        // Absolute size of the real body (open–close)
        public decimal bodyRange
        {
            get { return Math.Abs(close - open); }
        }

        // Upper shadow (wick)
        public decimal upperTailRange
        {
            get
            {
                decimal upperBody = Math.Max(open, close);
                return high - upperBody;
            }
        }

        // Lower shadow (wick)
        public decimal lowerTailRange
        {
            get
            {
                decimal lowerBody = Math.Min(open, close);
                return lowerBody - low;
            }
        }

        // Basic direction flags 
        /// <summary>
        /// bullish candlestick boolean
        /// </summary>
        public bool isBullish
        {
            get { return close > open; }
        }
        /// <summary>
        /// berish candlestick boolean
        /// </summary>
        public bool isBearish
        {
            get { return close < open; }
        }

        //1-candlestick patterns

        // Doji
        /// <summary>
        /// checks for doji candlestick
        /// </summary>
        public bool isDoji
        {
            get
            {
                if (range < MIN_VALID_RANGE) return false;
                decimal bodyPct = bodyRange / range;
                return bodyPct <= DOJI_BODY_MAX_PCT_OF_RANGE + LAX;
            }
        }

        // Body near high, long lower shadow
        /// <summary>
        /// checks for dragonfly doji candlestick
        /// </summary>
        public bool isDragonflyDoji
        {
            get
            {
                if (!isDoji || range < MIN_VALID_RANGE) return false;
                decimal lowerPct = lowerTailRange / range;
                decimal upperPct = upperTailRange / range;

                return (lowerPct >= LONG_TAIL_MIN_PCT_OF_RANGE - LAX) &&
                       (upperPct <= SHORT_TAIL_MAX_PCT_OF_RANGE + LAX);
            }
        }

        // Body near low, long upper shadow
        /// <summary>
        /// checks for gravestone doji candlestick
        /// </summary>
        public bool isGravestoneDoji
        {
            get
            {
                if (!isDoji || range < MIN_VALID_RANGE) return false;
                decimal upperPct = upperTailRange / range;
                decimal lowerPct = lowerTailRange / range;

                return (upperPct >= LONG_TAIL_MIN_PCT_OF_RANGE - LAX) &&
                       (lowerPct <= SHORT_TAIL_MAX_PCT_OF_RANGE + LAX);
            }
        }

        // Marubozu 

        public bool isMarubozu
        {
            get
            {
                if (range < MIN_VALID_RANGE) return false;

                decimal bodyPct = bodyRange / range;
                decimal upperPct = upperTailRange / range;
                decimal lowerPct = lowerTailRange / range;

                return (bodyPct >= MARUBOZU_BODY_MIN_PCT_OF_RANGE - LAX) &&
                       (upperPct <= MARUBOZU_TAIL_MAX_PCT_OF_RANGE + LAX) &&
                       (lowerPct <= MARUBOZU_TAIL_MAX_PCT_OF_RANGE + LAX);
            }
        }

        /// <summary>
        /// Checks for bullish Marubozu candlestick
        /// </summary>
        public bool isBullishMarubozu
        {
            get { return isMarubozu && isBullish; }
        }
        /// <summary>
        /// bearish Marubozu candlestick boolean
        /// </summary>
        public bool isBearishMarubozu
        {
            get { return isMarubozu && isBearish; }
        }

        // Hammer family 

        /// <summary>
        /// Checks for generic hammer and calculates parts of a hammer
        /// </summary>
        public bool isHammer
        {
            get
            {
                if (range < MIN_VALID_RANGE) return false;

                decimal bodyPct = bodyRange / range;
                decimal upperPct = upperTailRange / range;
                decimal lowerPct = lowerTailRange / range;

                bool smallBody = (bodyPct <= HAMMER_BODY_MAX_PCT_OF_RANGE + LAX);
                bool longLowerShadow = (lowerPct >= HAMMER_LONG_TAIL_MIN_PCT_OF_RANGE- LAX);
                bool shortUpper = (upperPct <= HAMMER_SHORT_TAIL_MAX_PCT_OF_RANGE+ LAX);

                return smallBody && longLowerShadow && shortUpper;
            }
        }

        /// <summary>
        /// Derived class from isHammer to check for bullish hammer
        /// </summary>
        public bool isBullishHammer
        {
            get { return isHammer && isBullish; }
        }
        /// <summary>
        /// Derived class from isHammer to check for bearish hammer
        /// </summary>
        public bool isBearishHammer
        {
            get { return isHammer && isBearish; }
        }

        //Inverted Hammer
        /// <summary>
        /// Checks for inverted hammer candlestick and calcs parts of inverted hammer
        /// </summary>
        public bool isInvertedHammer
        {
            get
            {
                if (range < MIN_VALID_RANGE) return false;

                decimal bodyPct = bodyRange / range;
                decimal upperPct = upperTailRange / range;
                decimal lowerPct = lowerTailRange / range;

                bool smallBody = (bodyPct <= HAMMER_BODY_MAX_PCT_OF_RANGE+ LAX);
                bool longUpperShadow = (upperPct >= HAMMER_LONG_TAIL_MIN_PCT_OF_RANGE- LAX);
                bool shortLower = (lowerPct <= HAMMER_SHORT_TAIL_MAX_PCT_OF_RANGE + LAX);

                return smallBody && longUpperShadow && shortLower;
            }
        }
        /// <summary>
        /// derived class from isInvertedHammer to check for bullish inverted hammer
        /// </summary>
        public bool isBullishInvertedHammer
        {
            get { return isInvertedHammer && isBullish; }
        }
        /// <summary>
        /// derived class from isInvertedHammer to check for bearish inverted hammer
        /// </summary>
        public bool isBearishInvertedHammer
        {
            get { return isInvertedHammer && isBearish; }
        }
    }
}


