﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_1
{
    public class Recognizers
    {
        public abstract class Recognizer
        {
            // candles are used for this pattern which will be 1 or 2 in our case
            public int PatternSize { get; protected set; }

            // patern name for combobox
            public string PatternName { get; protected set; }

            // Indices where this pattern occurs
            
            public List<int> PatternIndices { get; private set; } = new List<int>();

            protected Recognizer(string patternName, int patternSize)
            {
                PatternName = patternName;
                PatternSize = patternSize;
            }

            /// <summary>
            /// determine if the pattern is recognized at candles[i]
            /// </summary>
            /// <param name="candles"></param>
            /// <param name="i"></param>
            /// <returns></returns>
            public abstract bool Recognize(IList<aSmartCandlestick> candles, int i);

            /// <summary>
            /// Clear previously found indices.
            /// </summary>
            public virtual void Clear()
            {
                PatternIndices.Clear();
            }

            /// <summary>
            /// Utility: scan the whole list and populate PatternIndices.
            /// Your controller can call this for each Recognizer_xxx.
            /// </summary>
            public virtual void Scan(IList<aSmartCandlestick> candles)
            {
                Clear();
                if (candles == null) return;

                for (int i = 0; i <= candles.Count - PatternSize; i++)
                {
                    if (Recognize(candles, i))
                    {
                        PatternIndices.Add(i);
                    }
                }
            }
        }


        


        //DOJI
        /// <summary>
        /// Derermine if the candle is a Doji
        /// </summary>
        public class Recognizer_Doji : Recognizer
        {
            public Recognizer_Doji() : base("Doji", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isDoji;
            }
        }
        /// <summary>
        /// determine if the candle is a Bullish Doji
        /// </summary>
        public class Recognizer_BullishDoji : Recognizer
        {
            public Recognizer_BullishDoji() : base("Bullish Doji", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                var c = candles[i];
                return c.isDoji && c.isBullish;
            }
        }
        /// <summary>
        /// determine if the candle is a Bearish Doji
        /// </summary>
        public class Recognizer_BearishDoji : Recognizer
        {
            public Recognizer_BearishDoji() : base("Bearish Doji", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                var c = candles[i];
                return c.isDoji && c.isBearish;
            }
        }
        /// <summary>
        /// determine if the candle is a Dragonfly Doji
        /// </summary>
        public class Recognizer_DragonflyDoji : Recognizer
        {
            public Recognizer_DragonflyDoji() : base("Dragonfly Doji", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isDragonflyDoji;
            }
        }
        /// <summary>
        ///determine if the candle is a Gravestone Doji
        /// </summary>
        public class Recognizer_GravestoneDoji : Recognizer
        {
            public Recognizer_GravestoneDoji() : base("Gravestone Doji", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isGravestoneDoji;
            }
        }


        //hammer
        /// <summary>
        /// determine if the candle is a Hammer
        /// </summary>
        public class Recognizer_Hammer : Recognizer
        {
            public Recognizer_Hammer() : base("Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isHammer;
            }
        }
        /// <summary>
        /// determine if the candle is a Bullish Hammer
        /// </summary>
        public class Recognizer_BullishHammer : Recognizer
        {
            public Recognizer_BullishHammer() : base("Bullish Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                var c = candles[i];
                return c.isBullishHammer;
            }
        }
        /// <summary>
        /// determine if the candle is a Bearish Hammer
        /// </summary>
        public class Recognizer_BearishHammer : Recognizer
        {
            public Recognizer_BearishHammer() : base("Bearish Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                var c = candles[i];
                return c.isBearishHammer;
            }
        }

        //inverted hammer
        /// <summary>
        /// determine if the candle is an Inverted Hammer
        /// </summary>
        public class Recognizer_InvertedHammer : Recognizer
        {
            public Recognizer_InvertedHammer() : base("Inverted Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isInvertedHammer;
            }
        }
        /// <summary>
        /// determine if the candle is a Bullish Inverted Hammer
        /// </summary>
        public class Recognizer_BullishInvertedHammer : Recognizer
        {
            public Recognizer_BullishInvertedHammer() : base("Bullish Inverted Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isBullishInvertedHammer;
            }
        }
        /// <summary>
        /// determine if the candle is a Bearish Inverted Hammer
        /// </summary>
        public class Recognizer_BearishInvertedHammer : Recognizer
        {
            public Recognizer_BearishInvertedHammer() : base("Bearish Inverted Hammer", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isBearishInvertedHammer;
            }
        }

        // Marubozus
        /// <summary>
        /// determine if the candle is a Marubozu
        /// </summary>
        public class Recognizer_Marubozu : Recognizer
        {
            public Recognizer_Marubozu() : base("Marubozu", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isMarubozu;
            }
        }
        /// <summary>
        /// determine if the candle is a Bullish Marubozu
        /// </summary>
        public class Recognizer_BullishMarubozu : Recognizer
        {
            public Recognizer_BullishMarubozu() : base("Bullish Marubozu", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isBullishMarubozu;
            }
        }
        /// <summary>
        /// determine if the candle is a Bearish Marubozu
        /// </summary>
        public class Recognizer_BearishMarubozu : Recognizer
        {
            public Recognizer_BearishMarubozu() : base("Bearish Marubozu", 1) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return candles[i].isBearishMarubozu;
            }
        }

        


        // Helpers for 2-candle patterns
        /// <summary>
        /// helps with common calculations for patterns
        /// </summary>
        internal static class PatternHelpers
        {
            internal static void BodyBounds(aSmartCandlestick c,
                                            out decimal low, out decimal high)
            {
                low = Math.Min(c.open, c.close);
                high = Math.Max(c.open, c.close);
            }
        }

        //ENGULFING
        /// <summary>
        /// determine if the 2-candle pattern is an Engulfing pattern
        /// </summary>
        public class Recognizer_Engulfing : Recognizer
        {
            public Recognizer_Engulfing() : base("Engulfing", 2) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBullishEngulfing(candles, i) || IsBearishEngulfing(candles, i);
            }
            /// <summary>
            /// determine if the 2-candle pattern is a Bullish Engulfing pattern
            /// </summary>
            /// <param name="candles"></param>
            /// <param name="i"></param>
            /// <returns></returns>
            protected bool IsBullishEngulfing(IList<aSmartCandlestick> candles, int i)
            {
                var c1 = candles[i];
                var c2 = candles[i + 1];

                if (!c1.isBearish || !c2.isBullish)
                    return false;

                PatternHelpers.BodyBounds(c1, out var low1, out var high1);
                PatternHelpers.BodyBounds(c2, out var low2, out var high2);

                // second body completely engulfs first body
                return low2 <= low1 && high2 >= high1;
            }
            /// <summary>
            /// determine if the 2-candle pattern is a Bearish Engulfing pattern
            /// </summary>
            /// <param name="candles"></param>
            /// <param name="i"></param>
            /// <returns></returns>
            protected bool IsBearishEngulfing(IList<aSmartCandlestick> candles, int i)
            {
                var c1 = candles[i];
                var c2 = candles[i + 1];

                if (!c1.isBullish || !c2.isBearish)
                    return false;

                PatternHelpers.BodyBounds(c1, out var low1, out var high1);
                PatternHelpers.BodyBounds(c2, out var low2, out var high2);

                return low2 <= low1 && high2 >= high1;
            }
        }
        /// <summary>
        /// determine if the 2-candle pattern is a Bullish Engulfing pattern
        /// </summary>
        public class Recognizer_BullishEngulfing : Recognizer_Engulfing
        {
            public Recognizer_BullishEngulfing() : base()
            {
                PatternName = "Bullish Engulfing";
            }
            /// <summary>
            /// determine if the 2-candle pattern is a Bullish Engulfing pattern
            /// </summary>
            /// <param name="candles"></param>
            /// <param name="i"></param>
            /// <returns></returns>
            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBullishEngulfing(candles, i);
            }
        }
        /// <summary>
        /// determine if the 2-candle pattern is a Bearish Engulfing pattern
        /// </summary>
        public class Recognizer_BearishEngulfing : Recognizer_Engulfing
        {
            public Recognizer_BearishEngulfing() : base()
            {
                PatternName = "Bearish Engulfing";
            }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBearishEngulfing(candles, i);
            }
        }

        //harami
        /// <summary>
        /// determine if the 2-candle pattern is a Harami pattern
        /// </summary>
        public class Recognizer_Harami : Recognizer
        {
            public Recognizer_Harami() : base("Harami", 2) { }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBullishHarami(candles, i) || IsBearishHarami(candles, i);
            }

            protected bool IsBullishHarami(IList<aSmartCandlestick> candles, int i)
            {
                var c1 = candles[i];
                var c2 = candles[i + 1];

                if (!c1.isBearish || !c2.isBullish)
                    return false;

                PatternHelpers.BodyBounds(c1, out var low1, out var high1); 
                PatternHelpers.BodyBounds(c2, out var low2, out var high2);

                // second body contained inside first body
                return low2 >= low1 && high2 <= high1;
            }

            protected bool IsBearishHarami(IList<aSmartCandlestick> candles, int i)
            {
                var c1 = candles[i];
                var c2 = candles[i + 1];

                if (!c1.isBullish || !c2.isBearish)
                    return false;

                PatternHelpers.BodyBounds(c1, out var low1, out var high1);
                PatternHelpers.BodyBounds(c2, out var low2, out var high2);

                return low2 >= low1 && high2 <= high1;
            }
        }
        /// <summary>
        /// determine if the 2-candle pattern is a Bullish Harami pattern
        /// </summary>
        public class Recognizer_BullishHarami : Recognizer_Harami
        {
            public Recognizer_BullishHarami() : base()
            {
                PatternName = "Bullish Harami";
            }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBullishHarami(candles, i);
            }
        }
        /// <summary>
        /// determine if the 2-candle pattern is a Bearish Harami pattern
        /// </summary>
        public class Recognizer_BearishHarami : Recognizer_Harami
        {
            public Recognizer_BearishHarami() : base()
            {
                PatternName = "Bearish Harami";
            }

            public override bool Recognize(IList<aSmartCandlestick> candles, int i)
            {
                return IsBearishHarami(candles, i);
            }
        }
    }
}
