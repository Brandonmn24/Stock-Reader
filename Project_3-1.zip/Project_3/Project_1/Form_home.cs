﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_1
{
    public partial class Form_home : Form
    {
        public Form_home()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Event handler for file selection using OpenFileDialog, the function will loop through the list of files selected
        /// Calls Form_Display to display each ticker's data within the specified date range.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileDialog_fileSelector_FileOk(object sender, CancelEventArgs e)
        {
            int numberOfFiles = openFileDialog_fileSelector.FileNames.Length; //get the number of files selected
            //loop through each file selected and create a new Form_Display for each ticker
            for (int i = 0; i < numberOfFiles; i++)
            {
                string fileName = openFileDialog_fileSelector.FileNames[i]; //store fileName at ith index 
                Form_Display form_Display = new Form_Display(fileName, dateTimePicker_startDate.Value, dateTimePicker_endDate.Value); //call to create a new window with the ticker data


            }
        }

        private void button_loadTicker_Click(object sender, EventArgs e)
        {
            openFileDialog_fileSelector.ShowDialog(); //Show the file dialog to select files
        }
    }
}
